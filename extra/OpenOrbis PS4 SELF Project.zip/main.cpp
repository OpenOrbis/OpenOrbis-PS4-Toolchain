#include <stdio.h>

int main()
{
    // Your code here...
    return 0;
}