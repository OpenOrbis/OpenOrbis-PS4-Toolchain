#pragma once
#ifndef LIB_EXAMPLE
#define LIB_EXAMPLE

void dummy();

#endif