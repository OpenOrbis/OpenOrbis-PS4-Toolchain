#include <stdio.h>

#include "lib.h"

// Your library definitions here...

void dummy()
{
}