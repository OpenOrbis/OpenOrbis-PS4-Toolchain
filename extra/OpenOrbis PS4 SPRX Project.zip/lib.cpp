#include <stdio.h>

#include "libexample.h"

// Your library definitions here...

void dummy()
{
}